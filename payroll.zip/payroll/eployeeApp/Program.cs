﻿using System;

namespace employeeApp
{

    public class employee
    {
        private string employeeName = "";
        private int annualGrossSalary = 0;
        private int taxSalary = 0;

        public string name
        {
            get { return employeeName; }
            set { employeeName = value; }
        }

        public int grossSalary
        {
            get { return annualGrossSalary; }
            set { annualGrossSalary = value; }
        }

        public int tax
        {
            get { return taxSalary; }
            set { taxSalary = value; }
        }

        public employee()
        {
            Console.WriteLine("Employee Record created.");
        }

        public int CalcNet(int grossSalary, int tax)
        {
            int netSalary = grossSalary - ((tax * grossSalary) / 100);
            return netSalary;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int grossSalary = 0;
            int tax = 0;
            string name = "";
            employee Test = new employee();

            Console.Write("Please enter Employee's name: ");
            name = Console.ReadLine();
            Console.Write("Please enter Annual Gross Salary: ");
            grossSalary = int.Parse(Console.ReadLine());
            Console.Write("Please enter Tax Rate: ");
            tax = int.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.Write("Employee's name: ");
            Console.WriteLine(Test.name.ToString());
            Console.WriteLine("Net Salary: {0}", Test.CalcNet(grossSalary, tax).ToString());
        }
    }
}

