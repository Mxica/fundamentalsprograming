﻿using System;

namespace matrixApp
{
    public static class Matrix
    {
        // In this STATIC CLASS, we define all methods to be used
        // in the activity: 
        // *- randomGenerator: return a random number between the integers lowLimit and upLimit. These limits
        //                      can be specified from the MATRIX CONSTRUCTOR.
        // *- generateAndFillatrix: take parameters dimension, lowLimit and upLimit. THis method calls the
        //                      randomGenerator to fill the matrix.
        // *- calculateSumOfMatrices: takes two matrices and sum them. As indicated in the document, we supposed
        //                      matrices are square and with same size.
        // *- showMatrix: take a Matrix, reads it and print it in the console.
        public static int randomGenerator(int lowLimit, int upLimit)
        {
            Random random = new Random();
            return random.Next(lowLimit, upLimit);
        }

        public static int[,] generateAndFillMatrix(int dim, int lowLimit, int upLimit)
        {
            int[,] mx = new int[dim, dim];
            int row, col = 0;
            for (row = 0; row < dim; row++)
            {
                for (col = 0; col < dim; col++)
                {
                    mx[row, col] = randomGenerator(lowLimit, upLimit);
                }
            }
            return mx;
        }

        public static int[,] calculateSumOfMatrices(int[,] A, int[,] B)
        {
            int row, col = 0;
            int dA = A.GetLength(0);
            int dB = B.GetLength(0);

            int[,] mxSum = new int[dA, dB];
            for (row = 0; row < dA; row++)
            {
                for (col = 0; col < dA; col++)
                {
                    mxSum[row, col] = A[row, col] + B[row, col];
                }
            }

            return mxSum;
        }

        public static void showMatrix(int[,] A)
        {
            int row, col = 0;
            int dA = A.GetLength(0);
            for (row = 0; row < dA; row++)
            {
                for (col = 0; col < dA; col++)
                {
                    Console.Write("\t" + A[col, row] + "\t"); ;
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int[,] MatrixA = Matrix.generateAndFillMatrix(3, -10, 10);
            int[,] MatrixB = Matrix.generateAndFillMatrix(4, -10, 10);
            int[,] MatrixC = Matrix.calculateSumOfMatrices(MatrixA, MatrixB);
            Console.WriteLine("Matrix A:");
            Matrix.showMatrix(MatrixA);
            Console.WriteLine("Matrix B:");
            Matrix.showMatrix(MatrixB);
            Console.WriteLine("Matrix A + B:");
            Matrix.showMatrix(MatrixC);
        }
    }

}
