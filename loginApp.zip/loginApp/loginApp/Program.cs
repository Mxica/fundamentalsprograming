﻿using System;

namespace loginApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int iu, fu, fp = 0;
            string password1, password2;
            string username = "";
            Console.WriteLine("LOGIN SYSTEM");
            Console.WriteLine("************");
            Console.WriteLine("Welcome to Holiday Park system.");
            Console.WriteLine("Before you can continue, you must");
            Console.WriteLine("enter your USERNAME (once) and your ");
            Console.WriteLine("PASSWORD twice. Your username and");
            Console.WriteLine("your password must be 8 characters long.");
            Console.WriteLine("\n\n\n");

            do
            {
                Console.Write("Enter USERNAME: ");
                username = Console.ReadLine();
                fu = validateUsername(username);
            } while (fu == 0);

            do
            {
                Console.Write("Enter PASSWORD: ");
                password1 = Console.ReadLine();
                Console.Write("Confirm PASSWORD: ");
                password2 = Console.ReadLine();
                fu = validatePassword(password1, password2);
            } while (fu == 0);
        }

        static int validateUsername(string username)
        {
            int l = 0;
            int flag = 0;
            l = username.Length;
            if (l < 8)  // If USERNAME is less than 8 characters long, set Flag indicator to 0.
            {
                Console.WriteLine("USERNAME must have 8 characters long.");
                flag = 0;
            }
            else { flag = 1; }
            return flag;
        }

        static int validatePassword(string password1, string password2)
        {
            int l1 = 0;
            int l2 = 0;
            int flag = 0;
            l1 = password1.Length;
            l2 = password2.Length;
            if ((l1 < 8) & (l2 < 8))  // If USERNAME is less than 8 characters long, set Flag indicator to 0.
            {
                Console.WriteLine("Password must be 8 characters long.");
                if (l1 != l2)
                {
                    Console.WriteLine("Passwords must match.");
                    flag = 0;
                }
            }
            else
            {
                if (password1 == password2)
                {
                    Console.WriteLine("Password accepted.");
                    flag = 1;
                }
                else
                {
                    Console.WriteLine("Passwords doen't match.");
                    flag = 0;
                }
            }
            return flag;
        }
    }
}
